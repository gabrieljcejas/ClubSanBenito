yii-pjax Change Log
===================


2.0.2 Dec 4, 2014
-----------------
- Chg #12: Merged changes from upstream (samdark)

2.0.1 Oct 10, 2014
------------------
- Bug #9: Fixed missing history option in default settings (tonydspaniard)
- New #11: add new option "cache" (macklay)


2.0.0 Mar 20, 2014
------------------
- Bug: Fixed avoid duplicates of _pjax parameter (tof06)
- Bug: Fixed Pjax/GridView and back button (klevron, tof06, tonydspaniard)
